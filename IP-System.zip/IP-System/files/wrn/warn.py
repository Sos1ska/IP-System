import datetime, os

date_write = datetime.datetime.now()

def cl():
    os.system("clear")

def keyboard():
    global cl
    FRW = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRW.write('root:Warning "KeyboardInterrupt" - ' + str(date_write) + '\n')
    FRW.close()
    cl
    print('Сохранено по пути IP-System/files/log/log.txt')
    quit()

def file_not_found():
    global cl
    cl
    print('Проверьте все папки и файлы на правильность')
    print()
    print('Ошибка FileNotFoundError, исправление ошибки можете по github ссылке https://github.com/Sos1ska/RepairsCode')
    quit()

def i_e_colo():
    global cl
    cl
    print('Не установлен компонент Colorama')
    FRE = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRE.write('root:ImportError "Colorama" - ' + str(date_write) + '\n')
    FRE.close()
    quit()

def i_e_requ():
    global cl
    cl
    print('Не установлен компонент Requests')
    FRE = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRE.write('root:ImportError "Requests" - ' + str(date_write) + '\n')
    FRE.close()
    quit()