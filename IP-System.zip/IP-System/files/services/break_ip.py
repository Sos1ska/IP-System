import requests, urllib.request, json, os, datetime
from files.wrn.warn import keyboard, file_not_found
from colorama import Fore, Style, Back

date_write = datetime.datetime.now()

def cl():
    os.system("clear")

def start_ip():
    try:
        try:
            FRI = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
            FRS = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        FRS.write('root:StartCode "break_ip" - ' + str(date_write) + '\n')
        FRS.close()
        cl()
        print(Fore.YELLOW + 'Введите IP-адрес' + Style.RESET_ALL)
        ip_input = input(Fore.RED + Style.BRIGHT + '> ' + Style.RESET_ALL + Style.NORMAL)
        FRI.write(f'root:IntroducedCode "break_ip" - {str(ip_input)} - ' + str(date_write) + '\n')
        FRI.close()
        getinfoip = f'https://ipinfo.io/{str(ip_input)}/json'
        try:
            infoIp = urllib.request.urlopen( getinfoip )
        except:
            print('[!] - IP-адрес введён не верно - [!]')
            sleep(5)
            quit()
        infoIp = json.load( infoIp )
        try:
            print('Страна >>> ', infoIp["country"])
        except KeyError:
            print('Страна >>> Определить не удалось')
        try:
            print('Город >>> ', infoIp["city"])
        except KeyError:
            print('Город >>> Определить не удалось')
        try:
            print('Широта и долгота города >>> ', infoIp["loc"])
        except KeyError:
            print('Широта и долгота города >>> Определить не удалось')
        try:
            print('Название сети >>> ', infoIp["hostname"])
        except KeyError:
            print('Название сети >>> Определить не удалось')
        try:
            print('Провайдер >>> ', infoIp["org"])
        except KeyError:
            print('Провайдер >>> Определить не удалось')
    except KeyboardInterrupt:
        keyboard()