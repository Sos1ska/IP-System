import datetime, os
from time import sleep
try:
    from files.wrn.warn import file_not_found, keyboard, i_e_colo, i_e_requ
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:FileCode "warn" - not installed !' + '\n')
    FRTS.close()
try:
    from files.services.break_hosting import start_hosting
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:FileCode "break_hosting" - not installed !' + '\n')
    FRTS.close()
try:
    from files.services.break_ip import start_ip
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:FileCode "break_ip" - not installed !' + '\n')
    FRTS.close()
try:
    from files.services.break_mac import start_mac
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:FileCode "break_mac" - not installed !' + '\n')
    FRTS.close()
try:
    from files.services.break_isp import start_isp
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:FileCode "break_isp" - not installed !' + '\n')
    FRTS.close()
try:
    from colorama import Fore, Style, Back
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:Component "Colorama" - not installed !' + '\n')
    FRTS.close()
try:
    import requests
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:Component "Requests" - not installed !' + '\n')
    FRTS.close()

date_write = datetime.datetime.now()

def second_ip():
    print('''
.-------------------------------------------------------.
|                   Выберите функцию                    |
| _____________________________________________________ |
|                                                       |
| break_ip_geo_location - Местоположение IP-адреса      |  
| break_ip_ISP - Информация о провайдере                |
| break_ip_hosting - Узнать кому принадлежит сайт       |
| break_ip_mac - Узнать тип устройства через MAC-адрес  |
'-------------------------------------------------------'
    ''')

def start_code():
    print(f"S"),sleep(0.5),print(f" O"),sleep(0.5),print(f"  S"),sleep(0.5),print(f"   1"),sleep(0.5),print(f"    S"),sleep(0.5),print(f"     K"),sleep(0.5),print(f"      A"),sleep(2)

def cl():
    os.system("clear")

def start_main():
    global cl
    while True:
        cl()
        try:
            FRS = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        FRS.write('root:StartCode "main" - ' + str(date_write) + '\n')
        FRS.close()
        start_code()
        cl()
        second_ip()
        while True:
            menu_input = input(Fore.RED + Style.BRIGHT + '> ' + Style.RESET_ALL + Style.NORMAL)
            if str(menu_input) == "break_ip":
                start_ip()
            elif str(menu_input) == "break_ip_mac":
                start_mac()
            elif str(menu_input) == "break_ip_isp":
                start_isp()
            elif str(menu_input) == "break_ip_hosting":
                start_hosting()
            else:
                print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f': {str(menu_input)}')