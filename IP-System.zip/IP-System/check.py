import datetime, os, time

date_write = datetime.datetime.now()

def start_test():
    try:
        from files.main import start_main
        FRT = open('IP-System\\files\\test\\result.txt', 'w', encoding='utf-8')
        FRT.write(' root:FileCode "main" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "main" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.wrn import warn
        FRT.write('root:FileCode "warn" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "warn" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.services import break_ip
        FRT.write('root:FileCode "break_ip" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "break_ip" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.services import break_mac
        FRT.write('root:FileCode "break_mac" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "break_mac" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.services import break_isp
        FRT.write('root:FileCode "break_isp" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "break_isp" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.services import break_hosting
        FRT.write('root:FileCode "break_hosting" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write(f'root:FileCode "break_hosting" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from colorama import Fore, Style, Back
        FRT.write('root:Component "Colorama" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:Component "Colorama" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        import requests
        FRT.write('root:Component "Requests" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:Component "Reuqests" - not installed - ' + str(date_write) + '\n')
        pass
    FRT.close()

    FRR = open('IP-System\\files\\test\\result.txt', 'r', encoding='utf-8')
    print(*FRR)
    FRR.close()
    time.sleep(10)