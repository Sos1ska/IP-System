import datetime, os
try:
    from files.wrn.warn import keyboard, file_not_found
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:FileCode "warn" - not installed !')
    FRTS.close()
try:
    from files.main import start_main
except ImportError:
    FRTS = open('IP-System\error.txt', 'a', encoding='utf-8')
    FRTS.write('root:FileCode "main" - not installed !')
    FRTS.close()
from check import start_test

date_write = datetime.datetime.now()

def cl():
    os.system("clear")

try:
    try:
        FRS = open('IP-System\\files\log\log.txt', 'a', encoding='utf-8')
    except FileNotFoundError:
        file_not_found()
    FRS.write('root:StartCode "breakip" - ' + str(date_write) + '\n')
    FRS.close()
    cl()
    start_test()
    start_main()
except KeyboardInterrupt:
    keyboard()